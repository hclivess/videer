Info: MaskTools2 with dual filter signatures:

Some filter parameters such as "Y", "U", "V" and threshold parameter types has been changed 
from integer to float in order to support avs+ float type clips.

Problem: 
when someone is autoloading an older masktools2 (e.g. for 2.5 Avisynth, which has integer parameters), and then uses
LoadPlugin() later to load the new masktools2.dll, there can be troubles.

When the avs script contains filter calls with the usual integers, then Avisynth will find the old masktools2 because 
of the "best parameter match". When the filter is fed with 10+ bit clips, the script will fail 
with "Unsupported color space" because the old masktools2 dll is found and obviously it supports only 8 bit clips.

In the "dual filter signature" version each filter is defined twice, with parameter lists differing only in types.
One is with integer parameters, and one with float parameters.

Using this method Avisynth will choose the new dll even for filter instances used with integer parameters.

So use these dll versions if you are mixing your masktools dll's in the way described above.